package com.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
