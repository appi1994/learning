package com.olx.masterdata.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.olx.masterdata.dto.CategoryDto;
import com.olx.masterdata.dto.StatusDto;
import com.olx.masterdata.entity.Category;
import com.olx.masterdata.service.OlxMasterdataService;

@WebMvcTest(OlxMasterController.class)
public class OlxMasterDataControllerTest {
	
	@Autowired
	MockMvc mockMvc;//used to send request
	
	@MockBean
	OlxMasterdataService olxMasterdataService;
	
	@Autowired
	ObjectMapper objectMapper;

	
	@Test
	public void getAllCategory() throws Exception{
	List<CategoryDto> st= new ArrayList<>();
	st.add(new CategoryDto(1,"Furniture", "Furniture"));
	st.add(new CategoryDto(2,"Cars", "Cars"));
	
	when(olxMasterdataService.getAllCategory()).thenReturn(st);
	
	MvcResult mvcResult = this.mockMvc.perform(get("http://localhost:9001/olx/advertise/category"))
			.andExpect(status().isOk())
			.andReturn();
	String resString = mvcResult.getResponse().getContentAsString();
	assertTrue(resString.contains("Cars"));
	}
	
	@Test
	public void getAllStocks() throws Exception{
	List<StatusDto> st= new ArrayList<>();
	st.add(new StatusDto(1,"OPEN"));
	st.add(new StatusDto(2,"CLOSED"));
	
	when(olxMasterdataService.getAllStatus()).thenReturn(st);
	
	MvcResult mvcResult = this.mockMvc.perform(get("http://localhost:9001/olx/advertise/status"))
			.andExpect(status().isOk())
			.andReturn();
	String resString = mvcResult.getResponse().getContentAsString();
	assertTrue(resString.contains("CLOSED"));
	}
}
