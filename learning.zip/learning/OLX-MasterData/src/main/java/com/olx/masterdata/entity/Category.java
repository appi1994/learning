package com.olx.masterdata.entity;

import java.util.Objects;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(value  = "CATEGORIES")
public class Category {

	
	@Id
	private long id;
	
	private String category;
	
	private String description;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Category(long id, String category, String description) {
		this.id = id;
		this.category = category;
		this.description = description;
	}

	@Override
	public int hashCode() {
		return Objects.hash(category, description, id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Category other = (Category) obj;
		return Objects.equals(category, other.category) && Objects.equals(description, other.description)
				&& id == other.id;
	}

	@Override
	public String toString() {
		return "Category [id=" + id + ", category=" + category + ", description=" + description + "]";
	}

	public Category() {
	}

	public Category(String category, String description) {
		this.category = category;
		this.description = description;
	}

	
	
	
	
	
}
