package com.olx.masterdata.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.olx.masterdata.dto.CategoryDto;
import com.olx.masterdata.dto.StatusDto;
import com.olx.masterdata.entity.Category;
import com.olx.masterdata.entity.Status;
import com.olx.masterdata.repository.CategoryRepository;
import com.olx.masterdata.repository.StatusRepository;

@Service
public class OlxMasterdataServiceImpl implements OlxMasterdataService {

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	StatusRepository statusRepository;

	@Autowired
	ModelMapper objectMapper;
	@Override
	public List<CategoryDto> getAllCategory() {
		if (categoryRepository.count() <6) {
//			categoryDtos.stream().map(t->categoryRepository.save(t));
			categoryRepository.saveAll(categoryDtos);
		}
		return convertCategoryDtos(categoryRepository.findAll());
	}

	@Override
	public List<StatusDto> getAllStatus() {
		if (statusRepository.count() <2) {
			statusRepository.saveAll(statuslist);
		}
		return convertStatusDtos(statusRepository.findAll());
	}

	private static List<Status> statuslist = new ArrayList<>();
	static {
		statuslist.add(new Status(1,"OPEN"));
		statuslist.add(new Status(2,"CLOSED"));
	}

	private static List<Category> categoryDtos = new ArrayList<>();
	static {
		categoryDtos.add(new Category(1,"Furniture", "Furniture"));
		categoryDtos.add(new Category(2,"Cars", "Cars"));
		categoryDtos.add(new Category(3,"Mobiles", "Mobiles"));
		categoryDtos.add(new Category(4,"Real Estate", "Real Estate"));
		categoryDtos.add(new Category(5,"Sports", "Sports"));

	}

	public List<CategoryDto> convertCategoryDtos(List<Category> categories) {
		List<CategoryDto> categoryDtos = new ArrayList<>();
		for (Category category : categories) {
			CategoryDto cDto = objectMapper.map(category,CategoryDto.class);
			categoryDtos.add(cDto);
		}
		return categoryDtos;
	}

	public List<StatusDto> convertStatusDtos(List<Status> status) {
		List<StatusDto> statusDtos = new ArrayList<>();
		for (Status status2 : status) {
			StatusDto statss = objectMapper.map(status2, StatusDto.class);
			statusDtos.add(statss);
		}
		return statusDtos;
	}
}
