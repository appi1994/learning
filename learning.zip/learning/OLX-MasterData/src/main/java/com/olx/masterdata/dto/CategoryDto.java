package com.olx.masterdata.dto;

import io.swagger.v3.oas.annotations.media.Schema;

public class CategoryDto {
	
	private long id;
	@Schema(description = "category Name")
	private String category;
	private String description;
	public CategoryDto(long id, String category, String description) {
		this.id = id;
		this.category = category;
		this.description = description;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public CategoryDto(long id, String category) {
		this.id = id;
		this.category = category;
	}
	public CategoryDto() {
	}
	@Override
	public String toString() {
		return "CategoryDto [id=" + id + ", category=" + category + ", description=" + description + "]";
	}

	
	
}
