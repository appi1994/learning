package com.olx.masterdata.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.olx.masterdata.dto.CategoryDto;
import com.olx.masterdata.dto.StatusDto;
import com.olx.masterdata.service.OlxMasterdataService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping(value = "/olx")
public class OlxMasterController {

	@Autowired
	OlxMasterdataService olxMasterdataService;
	
	@Operation(summary = "List Advertise category", description = "List of Advertise Category.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Success "),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@GetMapping(value = "/advertise/category" ,   consumes = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<List<CategoryDto>> getAllCategory() {
		return new ResponseEntity<List<CategoryDto>>(olxMasterdataService.getAllCategory(),HttpStatus.OK);
	}
	
	@Operation(summary = "List Advertise Status", description = "List of Advertise Status.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Success "),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@GetMapping(value = "/advertise/status", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<List<StatusDto>> getAllStatus() {
		return new ResponseEntity<List<StatusDto>>(olxMasterdataService.getAllStatus(),HttpStatus.OK);
	}
	
	
}
