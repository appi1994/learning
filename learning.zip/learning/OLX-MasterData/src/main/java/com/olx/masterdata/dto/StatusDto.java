package com.olx.masterdata.dto;

import io.swagger.v3.oas.annotations.media.Schema;

public class StatusDto {

	private long id;
	@Schema(description = "Status like OPEN CLOSE")
	private String status;
	@Override
	public String toString() {
		return "Status [id=" + id + ", status=" + status + "]";
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public StatusDto(long id, String status) {
		super();
		this.id = id;
		this.status = status;
	}
	public StatusDto() {
		super();
	}
	
	
}
