package com.olx.masterdata.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.olx.masterdata.entity.Status;

public interface StatusRepository extends MongoRepository<Status, Integer> {

}
