package com.olx.masterdata.entity;

import java.util.Objects;

//import jakarta.persistence.Entity;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(value ="ADV_STATUS")
public class Status {
	
	@Id
	private long id;

	private String status;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Status(long id, String status) {
		this.id = id;
		this.status = status;
	}

	public Status() {
	}

	@Override
	public String toString() {
		return "Status [id=" + id + ", status=" + status + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Status other = (Status) obj;
		return id == other.id && Objects.equals(status, other.status);
	}

	public Status(String status) {
		this.status = status;
	}
	

	
}
