package com.olx.masterdata.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.olx.masterdata.dto.CategoryDto;
import com.olx.masterdata.dto.StatusDto;

public interface OlxMasterdataService {

	public List<CategoryDto> getAllCategory();
	
	public List<StatusDto> getAllStatus();
}
