package com.olx.user.exception;

public class InvalidTokenException {

}
