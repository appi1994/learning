package com.olx.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;

public class UserDto {

	private int id;

	@Schema(description = "userName of the User")
	private String userName;
	@Schema(description = "password of the USER ")
	private String password;
	@Schema(description = "roles of the USER ")
	private String roles;

	private String token;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public UserDto(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}

	public UserDto() {
		super();
	}
	@Override
	public String toString() {
		return "UserDto [id=" + id + ", userName=" + userName + ", password=" + password + ", roles=" + roles
				+ ", token=" + token + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRoles() {
		return roles;
	}
	public void setRoles(String roles) {
		this.roles = roles;
	}
	public UserDto(int id, String userName, String password, String roles,String token) {
		super();
		this.id = id;
		this.userName = userName;
		this.password = password;
		this.roles = roles;
		this.token =token;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}


}
