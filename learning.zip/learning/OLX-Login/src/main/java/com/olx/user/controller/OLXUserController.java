package com.olx.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.olx.user.dto.UserDto;
import com.olx.user.secutiry.JwtUtils;
import com.olx.user.service.OlxUserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/olx")
public class OLXUserController {

	@Autowired
	OlxUserService olxUserService;

	@Autowired
	AuthenticationManager authenticationManager;
	
	@Autowired
	UserDetailsService userDetailsService;


	@Autowired
	JwtUtils jwtUtils;
	private static UserDto userDto = new UserDto();

	@Operation(summary = "User Authenticate", description = "login User Authenticate.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@PostMapping(value = "/user/authenticate", consumes = { MediaType.APPLICATION_JSON_VALUE}, produces = { MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<UserDto> getAuthenticated(@RequestBody UserDto userDto) {
		System.out.println(userDto.toString());
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userDto.getUserName(),userDto.getPassword()));
			String jwtToken = jwtUtils.generateToken(userDto.getUserName());
			userDto.setToken(jwtToken);
			return new ResponseEntity<>(userDto, HttpStatus.OK);
		}catch (AuthenticationException e) {
			return new ResponseEntity<>( HttpStatus.BAD_REQUEST);
		}
	}
	@Operation(summary = "User Logout", description = "User Logout.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@DeleteMapping(value = "/user/logout", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<Boolean> deleteUser(@RequestHeader("Authorization") String authorization) {
		return new ResponseEntity(olxUserService.deleteUser(authorization), HttpStatus.OK);
	}

	@Operation(summary = "User Deatils", description = "User Deatils Using Userdata.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@PostMapping(value = "/user", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<UserDto> newUserRegister(@RequestBody UserDto userDto) {
		System.out.println(userDto.toString());
		if (olxUserService.newUserRegister(userDto) != null) {
			return new ResponseEntity<>(OLXUserController.userDto, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@Operation(summary = "User Deatils", description = "User Deatils.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@GetMapping(value = "/user", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<UserDto> getUserDeatils(@RequestHeader("Authorization") String authHeader) {
		String token = null;
        String username = null;
		if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
            username = jwtUtils.extractUsername(token);
        }
		if(username!=null) {
			return new ResponseEntity(olxUserService.getUserDeatils(username) ,HttpStatus.OK);
		}else {
			return new ResponseEntity( HttpStatus.BAD_REQUEST);
		}
        
		
	}

	@Operation(summary = "Validate Token", description = "Validate token for every request.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@GetMapping(value = "/token/validate", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<Boolean> getValidateToken(@RequestHeader("Authorization") String authHeader,@RequestHeader("EXPECTED_ROLES") String expectedRoles) {
		String token = null;
        String username = null;
		if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
            username = jwtUtils.extractUsername(token);
        }
		if(username!=null) {
            UserDetails userDetails = userDetailsService.loadUserByUsername(username);
            if (jwtUtils.validateToken(token, userDetails)) {
            	String authorities = userDetails.getAuthorities().toString();
            	String roleArray[] = expectedRoles.split(",");
            	for(String role: roleArray) {
            		if(authorities.contains(role)) {
            			return new ResponseEntity<Boolean>(true, HttpStatus.OK);
            		}
            	}
            }
		}
		return new ResponseEntity<Boolean>(false, HttpStatus.FORBIDDEN);
	}



}
