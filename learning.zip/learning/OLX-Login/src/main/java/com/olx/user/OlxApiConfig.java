package com.olx.user;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;

@OpenAPIDefinition(
		info = @Info(
				title = "Login Application",
				description = "Login  ",
				version = "1.1",
				license = @License(
						name = "ADV_Server",
						url = "http://9000.com"
				),
				contact = @Contact(
						name = "Anil",
						email = "anil.tj@zensar.com"
				)
		)
)
public class OlxApiConfig {

}
