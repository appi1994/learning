package com.olx.user.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.olx.user.entity.UserEntity;
import com.olx.user.repository.UserRepository;

@Service
public class UserDeatilsServiceImpl implements UserDetailsService{

	@Autowired
	UserRepository userRepository;


	@Autowired
	PasswordEncoder passwordEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		List<UserEntity> users = userRepository.findByUserName(username);
//		if(user.isPresent())
		if (users == null && users.size() == 0) {
			throw new UsernameNotFoundException("userNotfound");
		}
		UserEntity user = users.get(0);
		Collection<GrantedAuthority> authorities = new ArrayList<>();
		String roles = user.getRoles();
		String roleArray[] = roles.split(",");
		for(String role : roleArray) {
			GrantedAuthority g = new SimpleGrantedAuthority(role.trim());
			authorities.add(g);
		}
		UserDetails userdeatils = new User(user.getUserName(), passwordEncoder.encode(user.getPassword()), authorities);
		return userdeatils;
	}

}
