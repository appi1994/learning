package com.olx.user.secutiry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfiguration {

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	UserDetailsService userDetailsService;

	@Autowired
	JwtAuthFilter jwtAuthFilter;

	@Bean
	public SecurityFilterChain authorize(HttpSecurity httpSecurity) throws Exception {
			httpSecurity.csrf(csrf->csrf.disable())
			.authorizeHttpRequests(auth-> {

				auth.requestMatchers("/olx/user/gets").hasAnyRole("USER","MANAGER")
				.requestMatchers("/olx/user/authenticate").permitAll()
				.anyRequest().authenticated();
			}).formLogin(Customizer.withDefaults()).addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);
			//is coustimze lohin page we can add
//			.formLogin(Customizer.withDefaults());
			return httpSecurity.build();
		}

		@Bean
		public DaoAuthenticationProvider getAuthenticationProvider() {
			DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
			authProvider.setPasswordEncoder(passwordEncoder);
			authProvider.setUserDetailsService(userDetailsService);
			return authProvider;
		}

		@Bean
		public AuthenticationManager getAuthenticationManager(AuthenticationConfiguration config) throws Exception {
			return config.getAuthenticationManager();
		}
	//
//	@Bean
//	public UserDetailsService users() {
//		UserBuilder users = User.builder();
//		UserDetails tomuser= users.username("tom").password(passwordEncoder.encode("tom123")).roles("USER").build();
//		UserDetails aniluser= users.username("anil").password(passwordEncoder.encode("tom123")).roles("USER").build();
//		InMemoryUserDetailsManager inManager = new InMemoryUserDetailsManager(tomuser,aniluser);
//		return inManager;
//	}


}
