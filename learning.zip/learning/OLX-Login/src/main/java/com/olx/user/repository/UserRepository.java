package com.olx.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.olx.user.entity.UserEntity;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, Integer> {

//	Optional<UserEntity> findByUsername(String username);

//	  Boolean existsByUsername(String username);

//	  Boolean existsByEmail(String email);

	  List<UserEntity> findByUserName(String username);

}
