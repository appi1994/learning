package com.olx.user.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.olx.user.dto.UserDto;
import com.olx.user.entity.UserEntity;
import com.olx.user.repository.UserRepository;
@Service
public class OlxUserServiceImpl  implements OlxUserService{

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ModelMapper objectMapper;
	
	private static UserDto userDto = new UserDto();


	@Override
	public Boolean deleteUser(String authorization) {
		return true;
	}

	@Override
	public UserDto newUserRegister(UserDto userDto) {
		UserEntity userEntity = new UserEntity();
		userEntity.setPassword(userDto.getPassword());
		userEntity.setUserName(userDto.getUserName());
		userEntity.setRoles(userDto.getRoles());
		UserEntity u =userRepository.save(userEntity); 
		return converEntitytoDto(u);
	}

	@Override
	public UserDto getUserDeatils(String username) {
		UserEntity u =(UserEntity) userRepository.findByUserName(username);
		return converEntitytoDto(u);
	}


	public UserDto converEntitytoDto(UserEntity userEntity) {
		UserDto userDto = new UserDto();
		userDto.setUserName(userEntity.getUserName());
		userDto.setRoles(userEntity.getRoles());
		userDto.setId(userEntity.getId());
		return userDto;
	}
}
