package com.olx.user.exception;

public class SessionAlreadyExpiredException extends RuntimeException {

	private String message;

	@Override
	public String toString() {
		return "SessionAlreadyExpiredException [message=" + message + "]";
	}

	public SessionAlreadyExpiredException() {
	}

	public SessionAlreadyExpiredException(String message) {
		this.message = message;
	}
}
