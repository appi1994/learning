package com.olx.user.service;

import com.olx.user.dto.UserDto;

public interface OlxUserService {


	public Boolean deleteUser( String authorization);

	public UserDto newUserRegister( UserDto userDto);

	public UserDto getUserDeatils( String authorization);


}
