package com.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OlxApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(OlxApiGatewayApplication.class, args);
	}

}
