package com.example.thymleaf.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class FirstCOntroller {

	@RequestMapping(value= "contactus")
	public String requestMethodName(Model model) {
		model.addAttribute("asdasd","asdasd");
		return "contact_us" ;
	}
	
}
