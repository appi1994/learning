package com.example.thymleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
