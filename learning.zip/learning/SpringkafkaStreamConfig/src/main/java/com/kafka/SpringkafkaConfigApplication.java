package com.kafka;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.config.TopicBuilder;

@SpringBootApplication
public class SpringkafkaConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringkafkaConfigApplication.class, args);
	}
	//
	@Bean
	public NewTopic getFisrtTopic() {
		return TopicBuilder.name("first-topic").build();
	}

	@Bean
	public NewTopic getSecondTopic() {
		return TopicBuilder.name("second-topic").build();
	}
}
