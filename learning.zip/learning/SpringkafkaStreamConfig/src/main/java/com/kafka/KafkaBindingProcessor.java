package com.kafka;

import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KafkaBindingProcessor {
	
	Random random= new Random();
    //producer
    @Bean
    public Supplier<String> customProducer(){
        Supplier<String> supplier= ()-> {
            return "Hello kafka: "+random.nextInt(100);
        };
        return supplier;
    }
    //processor
    @Bean
    public Function<String, String> customProcessor(){
        Function<String, String> function= (String message)->{
            return message.toUpperCase();
        };
        return function;
    }
    
    //consumer
    @Bean
    public Consumer<String> customConsumer(){
    	System.out.println("consumer called");
        Consumer<String> consumer= (String message)-> {
            System.out.println("consumed message: "+ message);
        };
        return consumer;
    }	

}
