package com.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class MessageService {
	
	@Autowired
	KafkaTemplate<String,String> kafkaTemplate;
	
	
	@Autowired
	KafkaTemplate<String, Account> kafkaAccountTemplate;
	public MessageDto sendMessage(MessageDto messageDto) {
		this.kafkaTemplate.send("kafka-springboot-topic",messageDto.getMessage());
		return messageDto;
	}
	
	public Account sendAccountMessage(Account messageDto) {
		this.kafkaAccountTemplate.send("kafka-springboot-topic",messageDto);
		return messageDto;
	}

}
