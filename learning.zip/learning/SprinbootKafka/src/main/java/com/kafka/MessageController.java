package com.kafka;

//import java.awt.PageAttributes.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MessageController {
@Autowired
MessageService messageService;
		
		@PostMapping(value="/kafka-message", consumes=org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<MessageDto> sendMessage(@RequestBody MessageDto messageDto) {
			messageDto = messageService.sendMessage(messageDto);
			return new ResponseEntity<MessageDto>(messageDto, HttpStatus.OK);
	}
		
		
		@PostMapping(value="/kafka-message-account", consumes=org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Account> sendMessageaccount(@RequestBody Account messageDto) {
			messageDto = messageService.sendAccountMessage(messageDto);
			return new ResponseEntity<Account>(messageDto, HttpStatus.OK);
	}
}
