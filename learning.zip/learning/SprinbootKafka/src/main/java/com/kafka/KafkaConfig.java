package com.kafka;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.internals.Topic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

@Configuration
public class KafkaConfig {
	
	@Bean
	public NewTopic getTopic() {
		return new NewTopic("kafka-springboot-topic", 1, (short) 1);
	}

	
	@Bean
	public KafkaTemplate<String, String> getKafkaTemplate() {
		Map<String, String> config = new HashMap<String, String>();
		config.put("bootstrap.servers", "localhost:9092, localhost:9093");
		config.put("acks", "all");
		config.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		config.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		
		ProducerFactory<String, String> producerFactory =
				new DefaultKafkaProducerFactory(config);
		return new KafkaTemplate<String, String>(producerFactory);
	}

	
	@Bean
	public KafkaTemplate<String, Account> getAccountKafkaTemplate() {
		Map<String, String> config = new HashMap<String, String>();
		config.put("bootstrap.servers", "localhost:9092, localhost:9093");
		config.put("acks", "all");
		config.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		config.put("value.serializer", "org.springframework.kafka.support.serializer.JsonSerializer");
		
		ProducerFactory<String, Account> producerFactory =
				new DefaultKafkaProducerFactory(config);
		return new KafkaTemplate<String, Account>(producerFactory);
	}
}
