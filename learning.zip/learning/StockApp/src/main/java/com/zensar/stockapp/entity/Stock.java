package com.zensar.stockapp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="STOCKS")
public class Stock {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name="NAME")
	private String name;
	@Column(name="MARKET")
	private String market;
	@Column(name = "AMOUNT")
	private double amount;
	public Stock(String name, String market, double amount) {
		this.name = name;
		this.market = market;
		this.amount = amount;
	}
	public Stock() {
	}
	public String getName() {
		return name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Stock [name=" + name + ", market=" + market + ", amount=" + amount + "]";
	}

	
	
}
