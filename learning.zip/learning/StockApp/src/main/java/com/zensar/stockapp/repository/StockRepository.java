package com.zensar.stockapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.zensar.stockapp.entity.Stock;

public interface StockRepository extends JpaRepository<Stock, Integer>{
	List<Stock> findByName(String name);
	
///	@Query(value="SELECT * FROM STOCK  WHERE STOCK_NAME  LIKE '%:name%'",nativeQuery =true ) //sql by default false
//	List<Stock> finsdadsfdByName(@Param("name") String name);
	
//	@Query(value="select * from stock s where s.name LIKE %:name%") //JPQL
//	List<Stock> finsdfdByName(@Param("name") String name);
	
//	List<Stock> findbyOrderByNameAsc();// preDefined options
	
//	List<Stock> findAll()
}
