//package com.zensar.stockapp.acuator;
//
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
//import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
//import org.springframework.stereotype.Component;
//
//import jakarta.annotation.PostConstruct;
//
//
//@Component
//@Endpoint(id="/bugfixes")
//public class BugFixerAcutator {
//
//	private Map<String,List<String>>  bugs =new HashMap<>();
//	@PostConstruct
//	public void init() {
//		bugs.put("v1", Arrays.asList("UI not loading","applicationShutdown"));
//		bugs.put("v2", Arrays.asList("UI not loading","applica2tionShutdown"));
//		
//	}
//	
//	@ReadOperation
//	public Map<String,List<String>> getAllBugs(){
//		return this.bugs;
//	}
//}
