package com.zensar.stockapp.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class StockNameFoundException  extends RuntimeException{

	private String message;

	@Override
	public String toString() {
		return "StockNameFoundException [message=" + message + "]";
	}

	public StockNameFoundException(String message) {
		this.message = message;
	}

	public StockNameFoundException() {
	}
	
	
	
}
