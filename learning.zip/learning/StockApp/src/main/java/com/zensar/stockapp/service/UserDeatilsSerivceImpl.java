//package com.zensar.stockapp.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.authority.AuthorityUtils;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//
//import com.zensar.stockapp.entity.UserEntity;
//import com.zensar.stockapp.repository.UserRepository;
//
//public class UserDeatilsSerivceImpl implements  UserDetailsService {
//
//	@Autowired
//	UserRepository userRepository;
//	
//	@Override
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		UserEntity e= userRepository.findByUsername(username);
//		UserDetails user = new User(e.getUserName(), e.getPassword(), AuthorityUtils.NO_AUTHORITIES) ;
//		return user;
//	}
//
//}
