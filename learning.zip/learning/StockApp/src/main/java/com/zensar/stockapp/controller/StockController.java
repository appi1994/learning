package com.zensar.stockapp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.stockapp.dto.StockDto;
import com.zensar.stockapp.service.StockService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/zensarapp") // base path
public class StockController {

	@Autowired
	private StockService stockService;

//	private static List<StockDto> stocks = new ArrayList<>();
//	static {
//		stocks.add(new StockDto("IBM", "NSE", 25000));
//		stocks.add(new StockDto("Test", "NSE", 25000));
//		stocks.add(new StockDto("Ysafsdsa", "NSE", 25000));
//	}
	@GetMapping(value="")
	public String hello() {
	    return "list";
	}
	@GetMapping(path = "/stock")
	@Operation(description = "Stock list",summary = "get StackList ")
	public ResponseEntity<List<StockDto>> getAllStocks() {
		return new ResponseEntity<List<StockDto>>(stockService.getAllStocks(), HttpStatus.OK);
	}
	
	@PostMapping(value = "/stock", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_JSON_VALUE })
	@Operation(description = "Add Stocks to list")
	public ResponseEntity<StockDto> putStocks(
		@Valid	@RequestBody StockDto stockDto) {
		stockService.putStocks(stockDto);
		return new ResponseEntity<StockDto>(stockDto,HttpStatus.CREATED);
	}

	@PutMapping(value = "/stock/", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_JSON_VALUE })
	@Operation(description = "Add patch Stocks by using name")
	public ResponseEntity<StockDto> patchStocks(@RequestBody StockDto stockDto ) {
		StockDto sDto = stockService.patchStocks(stockDto, "");
		if (sDto == null)
			return new ResponseEntity<StockDto>(HttpStatus.BAD_REQUEST);
		return new ResponseEntity<StockDto>(sDto, HttpStatus.CREATED);
	}

	@DeleteMapping(value = "/stock/{name}")
	@Operation(description = "Delete Stocks by Name")
	public ResponseEntity<Boolean> getAllStocks(@PathVariable String name) {
		if (!stockService.getAllStocks(name)) {
			return new ResponseEntity<Boolean>(HttpStatus.BAD_REQUEST);
		} else {
			return new ResponseEntity<Boolean>(HttpStatus.OK);
		}
	}

	@GetMapping(value = "/stock/{name}")
	@Operation(description = "get Data of Stocks By name")
	public ResponseEntity<StockDto> getStockByname(@PathVariable String name) {
		StockDto sDto = stockService.getStockByname(name);
		if (sDto != null) {
			return new ResponseEntity<StockDto>(sDto, HttpStatus.OK);
		} else {
			return new ResponseEntity<StockDto>(HttpStatus.BAD_REQUEST);
		}
	}
	@GetMapping(value="/stock/name/{name}", produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<List<StockDto>> getStocksByName(@PathVariable("name") String name) {
			return new ResponseEntity<List<StockDto>>(stockService.findByName(name), HttpStatus.OK);
		}
	 
		@GetMapping(value="/stock/marketname/{marketname}", produces = MediaType.APPLICATION_JSON_VALUE)
		public List<StockDto> getStocksByMarketName(@PathVariable("marketname") String marketname) {
			return stockService.findByMarket(marketname);
		}
	 
		@GetMapping(value="/stock/marketname/{marketname}/name/{name}", produces = MediaType.APPLICATION_JSON_VALUE)
		public List<StockDto> getStocksByNameAndMarketName(@PathVariable("marketname") String marketname, @PathVariable("name") String name) {
			return stockService.findByNameAndMarket(name, marketname);
		}
	 
		@GetMapping(value="/stock/name/like/{name}", produces = MediaType.APPLICATION_JSON_VALUE)
		public List<StockDto> getStocksByNameLike(@PathVariable("name") String name) {
			return stockService.findByNameLike(name);
		}
	 
		@GetMapping(value="/stock/name/sort/{sortType}", produces = MediaType.APPLICATION_JSON_VALUE)
		public List<StockDto> getStocksOrderByName(@PathVariable("sortType") String sortType) {
			return stockService.findByOrderByName(sortType);
		}
	 
		@GetMapping(value="/stock/page/{startIndex}/{records}", produces = MediaType.APPLICATION_JSON_VALUE)
		public List<StockDto> getStocksByPage(@PathVariable("startIndex") int startIndex, @PathVariable("records") int records) {
			return stockService.findByPage(startIndex, records);
		}
}
