package com.zensar.stockapp.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;


public class StockDto {
	
	@Schema(description = "Name of the stock")
	@NotEmpty
	private String name;
	@Schema(description = "Market in which the stock is traded")
	private String market;
	@Schema(description = "Amount of the stock")
	private double amount;
	private int id;
	public StockDto(String name, String market, double amount) {
		super();
		this.name = name;
		this.market = market;
		this.amount = amount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public StockDto(@NotEmpty String name, String market, double amount, int id) {
		super();
		this.name = name;
		this.market = market;
		this.amount = amount;
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "StockDto [name=" + name + ", market=" + market + ", amount=" + amount + "]";
	}
	public StockDto() {
		super();
	}
	@Override
		public boolean equals(Object obj) {
			StockDto stock = (StockDto)obj;
			if(stock.name.equals(this.name))
				return true;
			return false;
		}
}
