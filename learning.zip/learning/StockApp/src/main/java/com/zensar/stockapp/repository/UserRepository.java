package com.zensar.stockapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.zensar.stockapp.entity.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, Integer> {

//	@Query(value="SELECT * FROM STOCK  WHERE STOCK_NAME  LIKE '%:name%'",nativeQuery =true ) //sql by default false
//	List<Stock> finsdadsfdByName(@Param("name") String name);
//	@Query(value = "select * from user where username=:name")
//	UserEntity findByUsername(@Param("name") String username) ;

}
