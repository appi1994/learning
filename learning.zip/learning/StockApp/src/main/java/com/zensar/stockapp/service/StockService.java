package com.zensar.stockapp.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.zensar.stockapp.dto.StockDto;

public interface StockService {

	public List<StockDto> getAllStocks ();
	
	public StockDto putStocks ( StockDto stockDto);
	
	public StockDto patchStocks ( StockDto stockDto, @PathVariable String name) ;
	
	public Boolean getAllStocks ( String name);
	
	public StockDto getStockByname ( String name);
	
	//Add inside StockService
		List<StockDto> findByMarket(String market);

		List<StockDto> findByName(String name);

		List<StockDto> findByNameAndMarket(String name, String market);

		List<StockDto> findByNameLike(String name);	

		List<StockDto> findByOrderByName(String sortType);

		List<StockDto> findByPage(int startIndex, int records);
}
