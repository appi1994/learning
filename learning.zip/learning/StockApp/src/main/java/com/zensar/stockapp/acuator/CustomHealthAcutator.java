//package com.zensar.stockapp.acuator;
//
//import java.util.Random;
//
//import org.springframework.boot.actuate.health.AbstractHealthIndicator;
//import org.springframework.boot.actuate.health.Health.Builder;
//import org.springframework.stereotype.Component;
//
//@Component
//public class CustomHealthAcutator extends AbstractHealthIndicator{
//
//	Random random = new Random();
//	
//	@Override
//	protected void doHealthCheck(Builder builder) throws Exception {
//		int no = random.nextInt(100);
//		if(no%2==0) {
//			builder.up();
//		}else {
//			builder.down();	
//		}
//	}
//}
