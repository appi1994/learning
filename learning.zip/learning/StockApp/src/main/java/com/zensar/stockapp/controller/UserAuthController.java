//package com.zensar.stockapp.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.zensar.stockapp.dto.StockDto;
//import com.zensar.stockapp.dto.UserDto;
//
//import io.swagger.v3.oas.annotations.Operation;
//import jakarta.validation.Valid;
//
//@RestController
//@RequestMapping("/zenstockapp") // base path
//public class UserAuthController {
//	
//	@Autowired
//	AuthenticationManager authenticationManager;
//
//	@PostMapping(value = "/authenticate", consumes = { MediaType.APPLICATION_JSON_VALUE,
//			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
//					MediaType.APPLICATION_JSON_VALUE })
//	public ResponseEntity<Boolean> putStocks(
//		@Valid	@RequestBody UserDto userDto) {
//	
////		try {
//			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userDto.getUserName(), userDto.getPassword()));
//			return new ResponseEntity<Boolean>(true,HttpStatus.CREATED);
////		}catch (Exception e) {
////			return new ResponseEntity<Boolean>(false,HttpStatus.CREATED);
////		}
//		
//	}
//}
