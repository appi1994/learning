package com.zensar.stockapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.zensar.stockapp.dto.StockDto;
import com.zensar.stockapp.entity.Stock;
import com.zensar.stockapp.exception.StockNameFoundException;
import com.zensar.stockapp.repository.StockRepository;

@Service
public class StackServiceImpl implements StockService {

	@Autowired
	StockRepository stockRepository;
	
	@Override
	public List<StockDto> getAllStocks() {
		return getListStockDto(stockRepository.findAll());
	}

	@Override
	public StockDto putStocks(StockDto stockDto) {
		stocks.add(stockDto);
		return stockDto;
	}

	@Override
	public StockDto patchStocks(StockDto stockDto, String name) {
		StockDto snew = stocks.stream().filter((s) -> s.getName().equals(stockDto.getName())).findAny().get();
		snew.setAmount(stockDto.getAmount());
		return snew;
	}

	@Override
	public Boolean getAllStocks(String name) {
		StockDto snew = stocks.stream().filter((s) -> s.getName().equals(name)).findAny().get();
		if (snew == null) {
			return false;
		} else {
			stocks.remove(snew);
			return true;
		}
	}

	@Override
	public StockDto getStockByname(String name) {
		StockDto snew = stocks.stream().filter((s) -> s.getName().equals(name)).findAny().get();
		if(snew==null) {
			 throw new StockNameFoundException("not found");
		}
		return snew;
	}

	private static List<StockDto> stocks = new ArrayList<>();
	static {
		stocks.add(new StockDto("IBM", "NSE", 25000));
		stocks.add(new StockDto("Test", "NSE", 25000));
		stocks.add(new StockDto("Ysafsdsa", "NSE", 25000));
	}
	@Override
	public List<StockDto> findByMarket(String market) {
		List<StockDto> snew = stocks.stream().filter((s) -> s.getMarket().contains(market)).collect(Collectors.toList());
		if(snew==null) {
			 throw new StockNameFoundException("not found");
		}
		return snew;
	}

	@Override
	public List<StockDto> findByName(String name) {
		List<StockDto> snew = stocks.stream().filter((s) -> s.getName().contains(name)).collect(Collectors.toList());
		if(snew==null) {
			 throw new StockNameFoundException("not found");
		}
		return snew;
	}

	@Override
	public List<StockDto> findByNameAndMarket(String name, String market) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<StockDto> findByNameLike(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<StockDto> findByOrderByName(String sortType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<StockDto> findByPage(int startIndex, int records) {
		org.springframework.data.domain.Pageable page = PageRequest.of(startIndex, records);
		 Page<Stock> page2=stockRepository.findAll(page);
		 List<Stock> ssss= page2.getContent();
		return null;
	}

	public List<StockDto> getListStockDto(List<Stock> stocks){
		List<StockDto> stDtos = new ArrayList<>();
		for(Stock s : stocks) {
		stDtos.add(new StockDto(s.getName(),s.getMarket(),s.getAmount(),s.getId()));
		}
		return stDtos;
	}
}
