package com.zensar.stockapp.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zensar.stockapp.dto.StockDto;
import com.zensar.stockapp.service.StockService;

import jakarta.validation.constraints.AssertTrue;

@WebMvcTest(StockController.class)
public class StockControllerTest {

	@Autowired
	MockMvc mockMvc;//used to send request
	
	@MockBean
	StockService stockService;
	
	@Autowired
	ObjectMapper objectMapper;
	
	@Test
	public void testAllgetStocks() throws Exception {
		List<StockDto> st= new ArrayList<>();
		st.add(new StockDto("anik","asdda",999));
		st.add(new StockDto("aniks","sasdda",90));
		
		when(stockService.getAllStocks()).thenReturn(st);
		
		MvcResult mvcResult = this.mockMvc.perform(get("http://localhost:9000/zensarapp/stock"))
				.andExpect(status().isOk())
				.andReturn();
		String resString = mvcResult.getResponse().getContentAsString();
		assertTrue(resString.contains("ani"));
	}
	
	
	@Test
	public void testAcreategetStocks() throws Exception {
		StockDto s= new  StockDto("anik","asdda",999);
		
		when(stockService.putStocks(s)).thenReturn(s);
		
		MvcResult mvcResult = this.mockMvc.perform(
				post("http://localhost:9000/zensarapp/stock").contentType("application/json").content(objectMapper.writeValueAsString(s)))
				.andExpect(status().isCreated())
				.andReturn();
		String resString = mvcResult.getResponse().getContentAsString();
		assertTrue(resString.contains("ani"));
	}
	
	@Test
	public void testAcreategetBlankStocks() throws Exception {
		StockDto s= new  StockDto("IBM","IBM",999);
		
		when(stockService.patchStocks(s,"")).thenReturn(s);
		
		MvcResult mvcResult = this.mockMvc.perform(
				put("http://localhost:9000/zensarapp/stock/").contentType("application/json").content(objectMapper.writeValueAsString(s)))
				.andExpect(status().isCreated())
				.andReturn();
		String resString = mvcResult.getResponse().getContentAsString();
		assertTrue(resString.contains("IBM"));
	}
}
