package com.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.kafka.dto.Account;

@Service
public class KafkaListnerService {

	@KafkaListener(topics = {"kafka-springboot-topic"},groupId = "test")
	public void reciveMessage(String message) {
		System.out.println("message ="+ message);
	}
	
	@KafkaListener(topics = {"kafka-springboot-topic"},groupId = "test")
	public void reciveMessage(Account message) {
		System.out.println("message ="+ message);
	}
}
