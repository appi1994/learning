package com.kafka.producer;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.Future;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import com.kafka.dto.UserDto;

public class AccountProducer {
	
	public static void simpleSynProducer() throws Exception {
		Producer producer = new KafkaProducer(getProrperties());
		ProducerRecord<String, UserDto> record_1 = new ProducerRecord<String, UserDto>("TestTopic", "flipkart.order.shoes",new UserDto(1,"anil",34444));
		ProducerRecord<String, UserDto> record_2 = new ProducerRecord<String, UserDto>("TestTopic", "flipkart.order",new UserDto(1,"shubha",34444));
		Future<RecordMetadata> future=producer.send(record_2);
		RecordMetadata recordMetadata = future.get();
		System.out.println("Message_1 partion number" +recordMetadata.partition()+"  offset"+recordMetadata.offset());
		Future<RecordMetadata> future1=producer.send(record_1);
		RecordMetadata recordMetadata1 = future1.get();
		System.out.println("Message_1 partion number" +recordMetadata1.partition()+"  offset"+recordMetadata1.offset());
//		producer.send(record_1);
		producer.close();
	}
	public static void main(String[] args) throws Exception {
//		simpleProducer();
		simpleSynProducer();
//		simpleAsyProducer();

	}
	
	public static Properties getProrperties() throws Exception {
		InputStream in = new FileInputStream("src/main/resources/application.properties");
		Properties prop =new Properties();
		prop.load(in);
		return prop;
	}


}
