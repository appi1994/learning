package com.kafka.producer;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

public class SentenceProducer {

	public static void simpleProducer() throws Exception {
		Producer<String, String> producer = new KafkaProducer<>(getProperties());
		
		ProducerRecord<String, String> record_1 = 
				new ProducerRecord<>("SentenceTopic", "sentence", "Hello Kafka streams");
		ProducerRecord<String, String> record_2 = 
				new ProducerRecord<>("SentenceTopic", "sentence", "Nice to learn kafka streams");
		
		producer.send(record_1);
		producer.send(record_2);
		producer.close();
		System.out.println("Senetences sent...");
	}
	public static void main(String[] args) throws Exception {
		simpleProducer();
	}
	public static Properties getProperties() throws Exception {
		Properties props = new Properties();
		props.put("bootstrap.servers", "localhost:9092");
		props.put("acks", "all");
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		return props;
	}

}
