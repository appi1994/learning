package com.kafka.consumer;

import java.io.FileInputStream;
import java.io.InputStream;
import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import com.kafka.dto.UserDto;

public class UserConsumer {
public static void synchronousConsumer() throws Exception{
		
		Consumer<String,UserDto> consumer = new KafkaConsumer<>(getProrperties());
		consumer.subscribe(Arrays.asList("TestTopic"));
		
		Duration duration = Duration.ofMillis(100);
		while(true) {
			ConsumerRecords<String , UserDto > records  = consumer.poll(duration);
			for(ConsumerRecord<String, UserDto> record : records) {
				System.out.println("Message from broker"+record.value().toString());
			}
		}
		
	}
//public static void SyncronousConsumer() throws Exception{
//	
//	Consumer<String,String> consumer = new KafkaConsumer<>(getProrperties());
//	consumer.subscribe(Arrays.asList("TestTopic"));
//	
//	Duration duration = Duration.ofMillis(100);
//	while(true) {
//		ConsumerRecords<String , String > records  = consumer.poll(duration);
//		for(ConsumerRecord<String, String> record : records) {
//			System.out.println("Message from broker"+record);
//		}
//	}
//	
//}
	
	
	public static void simpleConsumer() throws Exception{
		
		Consumer<String,String> consumer = new KafkaConsumer<>(getProrperties());
		consumer.subscribe(Arrays.asList("TestTopic"));
		
		Duration duration = Duration.ofMillis(100);
		while(true) {
			ConsumerRecords<String , String > records  = consumer.poll(duration);
			for(ConsumerRecord<String, String> record : records) {
				System.out.println("Message from broker"+record);
			}
		}
		
	}
	public static void main(String[] args) throws Exception {
		synchronousConsumer();	
	}
	
	public static Properties getProrperties() throws Exception {
		InputStream in = new FileInputStream("src/main/resources/application.properties");
		Properties prop =new Properties();
		prop.load(in);
		return prop;
	}


}
