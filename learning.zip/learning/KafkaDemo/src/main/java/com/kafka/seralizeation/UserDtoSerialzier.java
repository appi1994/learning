package com.kafka.seralizeation;

import java.nio.ByteBuffer;

import org.apache.kafka.common.serialization.Serializer;

import com.kafka.dto.UserDto;

public class UserDtoSerialzier implements Serializer<UserDto>{

	@Override
	public byte[] serialize(String topic, UserDto userDto) {
		if(userDto==null) {
			return null;
		}
		try {
		byte userNameArray[] = userDto.getName().getBytes("UTF-8");
		int sizeOfNameArray = userNameArray.length;
		
		ByteBuffer byteBuffer = ByteBuffer.allocate(4+4+sizeOfNameArray+8);
		byteBuffer.putInt(userDto.getId());
		byteBuffer.putInt(sizeOfNameArray);
		byteBuffer.put(userNameArray);
		byteBuffer.putDouble(userDto.getSalary());
		return byteBuffer.array();
		}catch (Exception e) {
			return null;
		}
	}

}
