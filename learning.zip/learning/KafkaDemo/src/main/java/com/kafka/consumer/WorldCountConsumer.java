//package com.kafka.consumer;
//
//import java.util.Properties;
//
//public class WorldCountConsumer {
//	
//	public static void main(String[] args) {
////		Strea
//	}
//
//	public static Properties getProperties() {
//		Properties props = new Properties();
//		props.put(StreamsConfig.APPLICATION_ID_CONFIG, "WORD_COUNT_DEMO_APP");
//		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092, localhost:9093");
//		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
//		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
//		return props;
//	}
//	
//}
//
