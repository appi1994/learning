package com.kafka.producer;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.Future;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

public class SampleProducer {

	public static void simpleSynProducer() throws Exception {
		Producer producer = new KafkaProducer(getProrperties());
		ProducerRecord<String, String> record_1 = new ProducerRecord<String, String>("TestTopic", "flipkart.order.shoes","Buy shoes");
		ProducerRecord<String, String> record_2 = new ProducerRecord<String, String>("TestTopic", "flipkart.order","Buy shoes");
		Future<RecordMetadata> future=producer.send(record_2);
		RecordMetadata recordMetadata = future.get();
		System.out.println("Message_1 partion number" +recordMetadata.partition()+"  offset"+recordMetadata.offset());
		Future<RecordMetadata> future1=producer.send(record_1);
		RecordMetadata recordMetadata1 = future1.get();
		System.out.println("Message_1 partion number" +recordMetadata1.partition()+"  offset"+recordMetadata1.offset());
		producer.send(record_1);
		producer.close();
	}

	public static void simpleAsyProducer() throws Exception {
		Producer producer = new KafkaProducer(getProrperties());
		ProducerRecord<String, String> record_1 = new ProducerRecord<String, String>("TestTopic", "flipkart.order.shoes","Buy shoes");
		ProducerRecord<String, String> record_2 = new ProducerRecord<String, String>("TestTopic", "flipkart.order.shirt","Buy shirt");
		ProducerRecord<String, String> record_3 = new ProducerRecord<String, String>("TestTopic", "flipkart.order.car","Buy car");
		ProducerRecord<String, String> record_4 = new ProducerRecord<String, String>("TestTopic", "flipkart.order.car","Buy car2");
		Callback callback = new MyCallBack();
		producer.send(record_2,callback);
		producer.send(record_1,callback);
		producer.send(record_3,callback);
		producer.send(record_4,callback);
		System.out.println("aftersending");
		producer.close();
	}
	
	static class MyCallBack implements Callback{

		@Override
		public void onCompletion(RecordMetadata metadata, Exception exception) {
			System.out.println("Message partion number" +metadata.partition()+"  offset"+metadata.offset());
			System.out.println();
		}
		
	}

	public static void main(String[] args) throws Exception {
//		simpleProducer();
//		simpleSynProducer();
		simpleAsyProducer();

	}
	
	public static Properties getProrperties() throws Exception {
		InputStream in = new FileInputStream("src/main/resources/application.properties");
		Properties prop =new Properties();
		prop.load(in);
		return prop;
	}
}
