package com.kafka.partion;

import java.util.List;
import java.util.Map;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;
import org.apache.kafka.common.PartitionInfo;

public class CustomPasrtitioner implements Partitioner {

	@Override
	public void configure(Map<String, ?> configs) {
System.out.println("custom config "+configs);		
	}

	@Override
	public int partition(String topic, Object key, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
		// TODO Auto-generated method stub
		List<PartitionInfo> partitionInfos = cluster.availablePartitionsForTopic(topic);
		int noPartition = partitionInfos.size();
		int partitionId= 0;
		if(key==null) {
			partitionId =0;
		}else if(key.equals("flipkart.order.shoes")||key.equals("flipkart.order.shoes") ) {
			if(noPartition>1) {
				partitionId =1;
			}else {
				partitionId =0;
			}
		}else if(key.equals("flipkart.order.car")) {
			if(noPartition>2) {
				partitionId =2;
			}else {
				partitionId =0;
			}
		}
		System.out.println("key = "+ key +"parttition id = "+partitionId);
		return partitionId;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		System.out.println("close function called");
		
	}

}
