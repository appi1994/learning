package com.kafka.seralizeation;

import java.nio.ByteBuffer;

import org.apache.kafka.common.serialization.Deserializer;

import com.kafka.dto.UserDto;

public class UserDtoDeseralizer implements Deserializer<UserDto>{

	@Override
	public UserDto deserialize(String topic, byte[] data) {
		// TODO Auto-generated method stub
		ByteBuffer byteBuffer = ByteBuffer.wrap(data);
		int id = byteBuffer.getInt();
		int sizeOfUserNameArray  = byteBuffer.getInt();
		byte nameArray[] = new byte [sizeOfUserNameArray] ;
		byteBuffer.get(nameArray);
		String name = new String(nameArray);
		double salary = byteBuffer.getDouble();
//		String name =byteBuffer.array();
		return new UserDto(id,name,salary);
	}

}
