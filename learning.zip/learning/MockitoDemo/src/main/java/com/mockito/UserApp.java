package com.mockito;

public class UserApp {
	UserService userService;
	
	public UserApp(UserService userService) {
		this.userService = userService;
	}
	
	public boolean login(String username, String password) {
		return this.userService.authenticate(username, password);
	}
	
	public UserDTO signup(UserDTO userDto) {
		return this.userService.register(userDto);
	}
}

