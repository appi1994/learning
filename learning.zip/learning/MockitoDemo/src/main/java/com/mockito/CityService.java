package com.mockito;

import java.util.List;

public interface CityService {
	List<String> findCitiesByCountry(String country);
}
