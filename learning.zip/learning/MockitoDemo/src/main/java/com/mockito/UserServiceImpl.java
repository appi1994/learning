package com.mockito;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserServiceImpl implements UserService {

	@Override
	public boolean authenticate(String username, String password) {
		try {
			Connection dbcon = DBUtils.getDBConnection();
			Statement stmt = dbcon.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM USERS WHERE username='" + username + "' AND password='" + password + "'");
			
			if(rs.next()) {
				return true;
			}
		}
		catch(SQLException | ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}

	@Override
	public UserDTO register(UserDTO userDto) {
		try {
			Connection dbcon = DBUtils.getDBConnection();
			Statement stmt = dbcon.createStatement();
			stmt.executeUpdate("INSERT INTO USERS VALUES('" + userDto.getUsername() + "','" + userDto.getPassword() + "','" + userDto.getFirstName() + "')");			
		}
		catch(SQLException | ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		return userDto;
	}
	}

