package com.mockito;

public interface UserService {
	boolean authenticate(String username, String password);
	UserDTO register(UserDTO userDto);
}
