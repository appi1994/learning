package com.mockito;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CityServiceImpl implements CityService {

	@Override
	public List<String> findCitiesByCountry(String country) {
		List<String> cities = new ArrayList<String>();
		try {
			Connection dbcon = DBUtils.getDBConnection();
			Statement stmt = dbcon.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM CITIES WHERE country='" + country + "'");
			
			while(rs.next()) {
				cities.add(rs.getString("city"));
			}
		}
		catch(SQLException | ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		return cities;
	}

}
