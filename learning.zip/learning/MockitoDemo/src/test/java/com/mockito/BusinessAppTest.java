package com.mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Test;

public class BusinessAppTest {

	@Test
	public void testBusinessAppWithMocking() {
		CityService cityService = mock(CityService.class);
		
		when(cityService.findCitiesByCountry("INDIA")).
			thenReturn(Arrays.asList("Pune", "Mumbai", "Delhi"));
		when(cityService.findCitiesByCountry("USA")).
			thenReturn(Arrays.asList("Washington", "New York"));
		
		BusinessApp businessApp = new BusinessApp(cityService);
		assertEquals(businessApp.retrieveCityListByCountry("INDIA").size(), 3);
	}
	
	@Test
	public void testBusinessApp() {
		CityService cityService = new CityServiceStubImpl();
		BusinessApp businessApp = new BusinessApp(cityService);
		assertEquals(businessApp.retrieveCityListByCountry("INDIA").size(), 3);
	}
}
