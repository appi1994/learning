package com.mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doCallRealMethod;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.mockito.Mockito;

public class UserAuthTest {

	@Test
	public void getAuthTest() {
		UserService userService = mock(UserService.class);
		UserApp userApp = new UserApp(userService);
		when(userApp.login("tom", "tom123")).thenReturn(true);
		assertEquals(userApp.login("tom", "tom123"), true);
	}

	@Test
	public void userNameblankOrNull() {
		UserService userService = mock(UserService.class);
		UserApp userApp = new UserApp(userService);
		when(userApp.login("tom", "tom123")).thenReturn(true);
		when(userApp.login(null, null)).thenThrow(NullPointerException.class);
		when(userApp.login(null, "tom123")).thenThrow(NullPointerException.class);
		assertEquals(userApp.login(null, "tom123"), false);
	}
	
	@Test
	public void userRegisterwithin() {
		UserService userService = mock(UserService.class);
		UserApp userApp = new UserApp(userService);
//		when(userApp.signup(new UserDTO("tom","tom123","t"))).thenReturn(new UserDTO("tom","tom123","t"));
		UserDTO s= new UserDTO("tom","tom123","t");
		userApp.signup(s);
		verify(userService).register(s);
		//verigy that method is called or not
	}
	
	@Test
	public     void testSignupCallsRegisterMethod() {
		UserService userService = mock(UserService.class);
		UserApp userApp = new UserApp(userService);
//		when(userApp.signup(new UserDTO("tom","tom123","t"))).thenReturn(new UserDTO("tom","tom123","t"));
		UserDTO s= new UserDTO("tom","tom123","t");
		doCallRealMethod().when(userService).authenticate(Mockito.anyString(), Mockito.anyString());
		userApp.signup(s);

        Mockito.verify(userService).register(s);

	}
}
