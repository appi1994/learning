package com.mockito;

import java.util.Arrays;
import java.util.List;

public class CityServiceStubImpl implements CityService {

	@Override
	public List<String> findCitiesByCountry(String country) {
		if(country.equals("INDIA")) {
			return Arrays.asList("Pune", "Mumbai", "Delhi");
		}
		else if(country.equals("USA")) {
			return Arrays.asList("Washington", "New York");
		}
		else {
			return null;
		}
	}

}
