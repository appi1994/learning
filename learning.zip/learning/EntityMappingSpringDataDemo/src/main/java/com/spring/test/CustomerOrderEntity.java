package com.spring.test;


@Entity
@Table(name="STOCKS")
public class CustomerOrderEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
    @Column(name="CUSTOMER_NAME")
    private String customername;
    @
    private List<FoodItemEntity> fooditems;
}