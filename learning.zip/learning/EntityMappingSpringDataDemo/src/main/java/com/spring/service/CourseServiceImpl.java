package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.entity.many_to_many.CourseEntity;
import com.spring.json.Course;
import com.spring.repo.CourseRepo;
import com.spring.util.StudentUtil;


@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseRepo courseRepo;
	
	@Override
	public Course createCourse(Course course) {
		CourseEntity cousre = StudentUtil.convertCourseIntoCourseEntity(course);
		cousre = courseRepo.save(cousre);
		return StudentUtil.convertCourseEntityIntoCourse(cousre);
	}

	@Override
	public List<Course> getAllCourse() {
		return StudentUtil.convertCourseEntityListIntoCorseList( courseRepo.findAll());
	}

}
