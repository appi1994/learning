package com.spring.service;

import java.util.List;

import com.spring.json.Course;


public interface CourseService {
	public Course createCourse(Course course);
	public List<Course> getAllCourse();
}
