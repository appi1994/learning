package com.spring.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.entity.many_to_many.CourseEntity;

public interface CourseRepo extends JpaRepository<CourseEntity, Long> {

}
