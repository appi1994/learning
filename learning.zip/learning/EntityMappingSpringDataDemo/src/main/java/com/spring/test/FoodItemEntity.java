package com.spring.test;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@javax.persistence.Entity
@Table(name="STOCKS")
public class FoodItemEntity {
    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
    
    @OneToOne(cascade={CascadeType.ALL},
			fetch=FetchType.LAZY)
	@JoinColumn(name="menu_id")
	private MenuEntity menu;
    
    @Column(name="QUANTITY")
	private int quantity;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public MenuEntity getMenu() {
		return menu;
	}

	public void setMenu(MenuEntity menu) {
		this.menu = menu;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "FoodItemEntity [id=" + id + ", menu=" + menu + ", quantity=" + quantity + "]";
	}

	public FoodItemEntity(int id, MenuEntity menu, int quantity) {
		super();
		this.id = id;
		this.menu = menu;
		this.quantity = quantity;
	}

	public FoodItemEntity() {
		super();
	}
    
    
}
