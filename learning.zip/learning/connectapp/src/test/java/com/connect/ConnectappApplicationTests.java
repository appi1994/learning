package com.connect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectappApplicationTests {

	@Test
	void contextLoads() {
	}

}
