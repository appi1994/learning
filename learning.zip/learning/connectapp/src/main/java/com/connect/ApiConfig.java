package com.connect;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApiConfig {

	private String appName;
	
	@Bean
	@Value("${spring.application.name}")		
	public String getAppName() {
		return this.appName;
	}
}
