package com.connect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnectappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConnectappApplication.class, args);
	}

}
