package com.apiversion;
import org.springframework.context.annotation.Bean;



public class Sample {

	int x=10;
	
}
