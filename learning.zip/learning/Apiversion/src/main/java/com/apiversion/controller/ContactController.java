package com.apiversion.controller;

import org.springframework.web.bind.annotation.RestController;

import com.apiversion.ApiConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
public class ContactController {
	
	@Autowired
	ApiConfig apiConfig;
	//http://localhost:8080/contact headers .accept =version value =application/contact.v1+json
		@GetMapping(value = "/contact" ,produces =  "application/contact.v2+json")
		public ResponseEntity<Contactv1>getMethodName7() {
			Contactv1 contact = new Contactv1("anil");
			return new ResponseEntity<Contactv1>(contact,HttpStatus.OK);
		}
		@GetMapping(value = "/contact",produces = "application/contact.v1+json")
		public ResponseEntity<Contactv2>getMethodName8() {
			Contactv2 contactv2 = new Contactv2("anils");
			return new ResponseEntity<Contactv2>(contactv2,HttpStatus.OK);
		
		}
	
	//http://localhost:8080/contact headers .key =version value =1
	@GetMapping(value = "/contact" ,headers  = "version=1")
	public ResponseEntity<Contactv1>getMethodName6() {
		Contactv1 contact = new Contactv1("anil");
		return new ResponseEntity<Contactv1>(contact,HttpStatus.OK);
	}
	@GetMapping(value = "/contact",headers = "version=2")
	public ResponseEntity<Contactv2>getMethodName5() {
		Contactv2 contact = new Contactv2("anil");
		return new ResponseEntity<Contactv2>(contact,HttpStatus.OK);
	
	}
	
	@GetMapping(value = "/app/name")
	public String getname() {
		return "app name " +apiConfig.getAppName();
	}
	
//http://localhost:8080/contact?version=1
	@GetMapping(value = "/contact" ,params = "version=1")
	public ResponseEntity<Contactv1>getMethodName3() {
		Contactv1 contact = new Contactv1("anil");
		return new ResponseEntity<Contactv1>(contact,HttpStatus.OK);
	}
	@GetMapping(value = "/contact",params = "version=2")
	public ResponseEntity<Contactv2>getMethodName4() {
		Contactv2 contact = new Contactv2("anil");
		return new ResponseEntity<Contactv2>(contact,HttpStatus.OK);
	
	}
	@GetMapping(value = "/v1/contact")
	public ResponseEntity<Contactv1>getMethodName() {
		Contactv1 contact = new Contactv1("anil");
		return new ResponseEntity<Contactv1>(contact,HttpStatus.OK);
	}
	@GetMapping(value = "/v2/contact")
	public ResponseEntity<Contactv2>getMethodName2() {
		Contactv2 contact = new Contactv2("anil");
		return new ResponseEntity<Contactv2>(contact,HttpStatus.OK);
	}
}

 class Contactv1{
	 String name;

	public Contactv1(String name) {
		this.name = name;
	}

	public Contactv1() {
	}

	@Override
	public String toString() {
		return "Contactv1 [name=" + name + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	 
}
 
 class Contactv2{
	 String firstName;

	public Contactv2(String firstName) {
		this.firstName = firstName;
	}

	public Contactv2() {
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	 
}