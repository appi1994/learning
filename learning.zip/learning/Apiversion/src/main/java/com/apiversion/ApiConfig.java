package com.apiversion;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
public class ApiConfig {
	@Value("${spring.application.name}")
	private String appName;
	
	@Autowired
	Sample sample;
	
	@Bean
	public String getAppName() {
		return this.appName;
	}
	
	@Bean
	@Profile(value = { "prod" })
	public Sample getNae() {
		return sample;
	}
}
