package com.olx.advertise.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
//import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.olx.advertise.dto.AdvertiseDto;
import com.olx.advertise.dto.Category;
import com.olx.advertise.dto.NewAdvertisementPostRequest;
import com.olx.advertise.dto.NewAdvertisementPostResponse;
import com.olx.advertise.entity.Advertises;
import com.olx.advertise.exception.InvalidAdvertiseIdException;
import com.olx.advertise.exception.InvalidTokenException;
import com.olx.advertise.repository.AdvertiseRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

@Service
public class OlxAdvertiseServiceImpl implements OlxAdvertiseServie {

	@Autowired
	AdvertiseRepository advertiseRepository;

	@Autowired
	private EntityManager entityManager;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	CategoryService categoryService;

	@Autowired
	UserDelegateService userDelegateService;

	@Override
	public NewAdvertisementPostResponse postNewAdvertise(NewAdvertisementPostRequest advertiseDto, String authHeader,
			String expectedRoles) {
		CheckTokenException(authHeader, expectedRoles);
		Advertises advertises = new Advertises();
		advertises.setActive(true);
		advertises.setTitle(advertiseDto.getTitle());
		advertises.setPrice(advertiseDto.getPrice());
		advertises.setDescription(advertiseDto.getDescription());
		advertises.setCreatedDate(new Date().toLocaleString());
		Category c = categoryService.getCategoryByID(advertiseDto.getCategoryId());
		advertises.setCategory(c.getName());
		advertises.setCategory("Test");
		advertises.setStatus("OPEN");
		Advertises advertises2 = advertiseRepository.save(advertises);
		NewAdvertisementPostResponse response = new NewAdvertisementPostResponse();
		response.setTitle(advertiseDto.getTitle());
		response.setPrice(advertiseDto.getPrice());
		response.setDescription(advertiseDto.getDescription());
		response.setModifiedDate(LocalDate.now());
		return response;
	}

	@Override
	public AdvertiseDto getAdvertisebyID(AdvertiseDto advertiseDto, String id, String authHeader,
			String expectedRoles) {
		CheckTokenException(authHeader, expectedRoles);
		Optional<Advertises> as = advertiseRepository.findById(Long.valueOf(id));
		if (as.isEmpty()) {
			throw new InvalidAdvertiseIdException("Invalid exception");
		}
		return getAdvertiseDto(as.get());
	}

	@Override
	public List<AdvertiseDto> getAdvertiseList(String authHeader, String expectedRoles) {
		CheckTokenException(authHeader, expectedRoles);
		if (userDelegateService.getValidateToken(authHeader, expectedRoles)) {
			return getListOfAdverDtos(advertiseRepository.findAll());
		}
		return new ArrayList<>();
	}

	@Override
	public AdvertiseDto getAdvertiseByID(String id, String authHeader, String expectedRoles) {
		CheckTokenException(authHeader, expectedRoles);
		Optional<Advertises> as = advertiseRepository.findById(Long.valueOf(id));
		if (as.isEmpty()) {
			throw new InvalidAdvertiseIdException("Invalid exception");
		}
		return getAdvertiseDto(as.get());
	}

	@Override
	public AdvertiseDto getAdvertiseSearchByText(String match) {

		return null;
	}

	@Override
	public AdvertiseDto getAdvertiseSearchByadId(String advertiseId) {
		Optional<Advertises> advertise = (advertiseRepository.findById(Long.valueOf(advertiseId)));
		if (advertise.isPresent())
			return getAdvertiseDto(advertise.get());
		throw new InvalidAdvertiseIdException("Advertise Not found");
	}

	@Override
	public AdvertiseDto getAdvertiseSearch(LocalDate onDate) {
		Advertises adOptional = advertiseRepository.findByCreatedDate(onDate.toString());
		if (adOptional != null)
			return getAdvertiseDto(adOptional);
		throw new InvalidAdvertiseIdException("Advertise Not found");
	}

//	private static AdvertiseDto advertiseDto = new AdvertiseDto(); 
//	private static List<AdvertiseDto> adlist = new ArrayList<>();
//	static {
//		adlist.add(new AdvertiseDto(1,"ttt",2,"sadsd","Adsad","dasadsa","asdadad","OPEN","anil",23333));
//		adlist.add(new AdvertiseDto(2,"ttt",2,"sadsd","Adsad","dasadsa","asdadad","OPEN","anil",23333));
//		adlist.add(new AdvertiseDto(3,"ttt",2,"sadsd","Adsad","dasadsa","asdadad","OPEN","anil",23333));
//	}

	public AdvertiseDto getAdvertiseDto(Advertises advertises) {
		AdvertiseDto advertises2 = new AdvertiseDto();
		advertises2.setId(advertises2.getId());
		advertises2.setPrice(advertises2.getPrice());
		advertises2.setTitle(advertises.getTitle());
		advertises2.setDescription(advertises.getDescription());
		advertises2.setStatus(advertises.getStatus());
		return advertises2;
	}

	public List<AdvertiseDto> getListOfAdverDtos(List<Advertises> advList) {
		List<AdvertiseDto> adDtos = new ArrayList<>();
		for (Advertises ad : advList) {
			AdvertiseDto advertises2 = new AdvertiseDto();
			advertises2.setId(ad.getId());
			advertises2.setPrice(ad.getPrice());
			advertises2.setTitle(ad.getTitle());
			advertises2.setDescription(ad.getDescription());
			advertises2.setStatus(ad.getStatus());
		}
		return adDtos;
	}

	public List<AdvertiseDto> searchAdvertiseByFilterCriteria(String searchText, String title, String description,
			String sortedBy, int startIndex, int records) {

		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Advertises> criteriaQuery = criteriaBuilder.createQuery(Advertises.class);
		Root<Advertises> rootEntity = criteriaQuery.from(Advertises.class);

		Predicate searchTextPredicate = criteriaBuilder.and();
		Predicate namePredicate = criteriaBuilder.and();
		Predicate marketPredicate = criteriaBuilder.and();

		if (searchText != null && !"".equals(searchText)) { // user has sent searchText value
			// name like '%searchText%'
			Predicate nameSearchTextPredicate = criteriaBuilder.like(rootEntity.get("title"), "%" + searchText + "%");
			// market like '%searchText%'
			Predicate marketSearchTextPredicate = criteriaBuilder.like(rootEntity.get("description"),
					"%" + searchText + "%");
			searchTextPredicate = criteriaBuilder.or(nameSearchTextPredicate, marketSearchTextPredicate);
		}
		// build criteria for name & market
		if (title != null && !"".equals(title)) {
			// name = :name
			namePredicate = criteriaBuilder.equal(rootEntity.get("title"), title);
		}
		if (description != null && !"".equals(description)) {
			// market = :market
			marketPredicate = criteriaBuilder.equal(rootEntity.get("description"), description);
		}

		if (sortedBy != null && !"".equals(sortedBy)) {
			if ("asc".equalsIgnoreCase(sortedBy))
				criteriaQuery.orderBy(criteriaBuilder.asc(rootEntity.get("title")));
			else if ("desc".equalsIgnoreCase(sortedBy))
				criteriaQuery.orderBy(criteriaBuilder.desc(rootEntity.get("title")));
		}
		Predicate finalPredicate = criteriaBuilder.and(searchTextPredicate, namePredicate, marketPredicate);
		criteriaQuery.where(finalPredicate);

		TypedQuery<Advertises> typedQuery = entityManager.createQuery(criteriaQuery);
		typedQuery.setFirstResult(startIndex);
		typedQuery.setMaxResults(records);
		List<Advertises> stockEntityList = typedQuery.getResultList(); // Query is executed
		return getListOfAdverDtos(stockEntityList);
	}

	@Override
	public AdvertiseDto getAdvertiseDeleteByadId(String advertiseId, String authHeader, String expectedRoles) {
		CheckTokenException(authHeader, expectedRoles);
		advertiseRepository.deleteById(Long.getLong(advertiseId));
		return null;
	}

	public void CheckTokenException(String authHeader, String expectedRoles) {
		if (!userDelegateService.getValidateToken(authHeader, expectedRoles)) {
			throw new InvalidTokenException("Not Authirised User Token");
		}
	}

}
