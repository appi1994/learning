package com.olx.advertise.exception;

public class DateNotFoundException extends RuntimeException {
	
	private String message;

	@Override
	public String toString() {
		return "DateNotFoundException [message=" + message + "]";
	}

	public DateNotFoundException() {
	}

	public DateNotFoundException(String message) {
		this.message = message;
	}
}
