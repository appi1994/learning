package com.olx.advertise.entity;

import java.sql.Blob;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="ADVERTISES")
public class Advertises {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "title")
	private String title;
//	@Column(name = "category")
//	private long categoryID;
	@Column(name = "category")
	private String category;
	@Column(name = "description")
	private String description;
	
	@Column(name = "created_date")
    @Temporal(TemporalType.DATE)
	private String createdDate; 
	@Column(name = "modified_date")
	private String modifiedDate;
	@Column(name = "status")
	private String status;
	@Column(name = "name")
	private String postedBy;
	@Column(name = "price")
	private double price;
	@Column(name= "photo")
	private Blob photo;
	
	@Column(name="active")
	private boolean active;
	@Column(name = "username")
	private String username;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPostedBy() {
		return postedBy;
	}
	public void setPostedBy(String postedBy) {
		this.postedBy = postedBy;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Blob getPhoto() {
		return photo;
	}
	public void setPhoto(Blob photo) {
		this.photo = photo;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Override
	public String toString() {
		return "Advertises [id=" + id + ", title=" + title + ", category=" + category + ", description=" + description
				+ ", createdDate=" + createdDate + ", modifiedDate=" + modifiedDate + ", status=" + status
				+ ", postedBy=" + postedBy + ", price=" + price + ", photo=" + photo + ", active=" + active
				+ ", username=" + username + "]";
	}
	public Advertises(String title, String category, String description, String createdDate, String modifiedDate,
			String status, String postedBy, double price, Blob photo, boolean active, String username) {
		this.title = title;
		this.category = category;
		this.description = description;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.status = status;
		this.postedBy = postedBy;
		this.price = price;
		this.photo = photo;
		this.active = active;
		this.username = username;
	}
	public Advertises() {
	}
	
}
