package com.olx.advertise.service;

public interface UserDelegateService {

	public boolean getValidateToken(String token, String expectedRoles);
}
