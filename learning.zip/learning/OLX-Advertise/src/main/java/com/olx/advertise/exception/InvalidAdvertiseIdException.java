package com.olx.advertise.exception;

public class InvalidAdvertiseIdException extends RuntimeException {
	
	private String message;

	@Override
	public String toString() {
		return "InvalidAdvertiseIdException [message=" + message + "]";
	}

	public InvalidAdvertiseIdException() {
	}

	public InvalidAdvertiseIdException(String message) {
		this.message = message;
	}
	
}
