package com.olx.advertise.dto;

import java.util.Objects;

public class NewAdvertisementPostRequest {
	
	int id;
	String title;
	int categoryId;
	String description;
	double price;
	int statusId;
	public NewAdvertisementPostRequest(int id, String title, int categoryId, String description, double price,
			int statusId) {
		this.id = id;
		this.title = title;
		this.categoryId = categoryId;
		this.description = description;
		this.price = price;
		this.statusId = statusId;
	}
	public NewAdvertisementPostRequest() {
	}
	@Override
	public String toString() {
		return "NewAdvertisementPostRequest [id=" + id + ", title=" + title + ", categoryId=" + categoryId
				+ ", description=" + description + ", price=" + price + ", statusId=" + statusId + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStatusId() {
		return statusId;
	}
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}
	@Override
	public int hashCode() {
		return Objects.hash(categoryId, description, id, price, statusId, title);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NewAdvertisementPostRequest other = (NewAdvertisementPostRequest) obj;
		return categoryId == other.categoryId && Objects.equals(description, other.description) && id == other.id
				&& Double.doubleToLongBits(price) == Double.doubleToLongBits(other.price) && statusId == other.statusId
				&& Objects.equals(title, other.title);
	}
	public NewAdvertisementPostRequest(int id) {
		this.id = id;
	}

	
	

}
