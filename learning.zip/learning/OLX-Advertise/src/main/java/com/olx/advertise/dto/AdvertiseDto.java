package com.olx.advertise.dto;

import io.swagger.v3.oas.annotations.media.Schema;

public class AdvertiseDto {

	private long id;
	@Schema(description = "Title Of Advertise")
	private String title;
	@Schema(description = "Advertise categoryID")
	private long categoryID;
	@Schema(description = "Category name")
	private String category;
	@Schema(description = "Advertise Description")
	private String description;
	@Schema(description = "Advertise Created Date")
	private String createdDate;
	@Schema(description = "Advertise Modification Date")
	private String modifiedDate;
	@Schema(description = "Advertise Status")
	private String status;
	@Schema(description = "Advertise posted By User")
	private String postedBy;
	@Schema(description = "Advertise price ")
	private double price;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public long getCategoryID() {
		return categoryID;
	}
	public void setCategoryID(long categoryID) {
		this.categoryID = categoryID;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPostedBy() {
		return postedBy;
	}
	public void setPostedBy(String postedBy) {
		this.postedBy = postedBy;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "AdvertiseDto [id=" + id + ", title=" + title + ", categoryID=" + categoryID + ", category=" + category
				+ ", description=" + description + ", createdDate=" + createdDate + ", modifiedDate=" + modifiedDate
				+ ", status=" + status + ", postedBy=" + postedBy + ", price=" + price + "]";
	}
	public AdvertiseDto(long id, String title, long categoryID, String category, String description,
			String createdDate, String modifiedDate, String status, String postedBy, double price) {
		super();
		this.id = id;
		this.title = title;
		this.categoryID = categoryID;
		this.category = category;
		this.description = description;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
		this.status = status;
		this.postedBy = postedBy;
		this.price = price;
	}
	public AdvertiseDto() {
		super();
	}
	
	
	
}
