package com.olx.advertise.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.olx.advertise.dto.AdvertiseDto;
import com.olx.advertise.dto.NewAdvertisementPostRequest;
import com.olx.advertise.dto.NewAdvertisementPostResponse;
import com.olx.advertise.service.OlxAdvertiseServie;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.*;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping(value = "/olx")
public class OLXAdvertiseController {

	@Autowired
	private OlxAdvertiseServie olxAdvertiseServie;
	
	@Operation(summary = "Add Advertise", description = "Add new Advertise for sale.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "201", description = "Successfully Added"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@PostMapping(value = "/advertise", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<NewAdvertisementPostResponse> postNewAdvertise(@RequestBody NewAdvertisementPostRequest advertiseDto,@RequestHeader("Authorization") String authHeader,@RequestHeader("EXPECTED_ROLES") String expectedRoles){
		return new ResponseEntity<NewAdvertisementPostResponse>(olxAdvertiseServie.postNewAdvertise(advertiseDto,authHeader,expectedRoles),HttpStatus.CREATED);
	}

	@Operation(summary = "Get Advertise By ID", description = "Find  Advertise for sale by ID .")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Successfully Found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@PutMapping(value = "/advertise/{id}" , consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<AdvertiseDto> getAdvertisebyID(@RequestBody AdvertiseDto advertiseDto,@PathVariable String id,@RequestHeader("Authorization") String authHeader,@RequestHeader("EXPECTED_ROLES") String expectedRoles) {
		return new ResponseEntity<AdvertiseDto>(olxAdvertiseServie.getAdvertiseByID(id,authHeader,expectedRoles),HttpStatus.OK);
	}
	
	
	@Operation(summary = "Get All Advertise", description = "Getting Advertise for sale.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Successfully geting All list"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@GetMapping(value ="user/advertise" , consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<List<AdvertiseDto>> getAdvertiseList(@RequestHeader("Authorization") String authHeader,@RequestHeader("EXPECTED_ROLES") String expectedRoles) {
		return new ResponseEntity<List<AdvertiseDto>>(olxAdvertiseServie.getAdvertiseList(authHeader,expectedRoles),HttpStatus.OK);
	}
	
	
	@Operation(summary = "Get Advertise by ID", description = "Get Advertise by ID.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Successfully geting Advertise"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@GetMapping(value = "user/advertise/{id}", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<AdvertiseDto> getAdvertiseByID(@PathVariable String id,@RequestHeader("Authorization") String authHeader,@RequestHeader("EXPECTED_ROLES") String expectedRoles) {
		System.out.println(id);
		return new ResponseEntity<AdvertiseDto>(olxAdvertiseServie.getAdvertiseByID(id,authHeader,expectedRoles),HttpStatus.OK);
	}
	
	@Operation(summary = "Get Advertise by regex", description = "Get Advertise by regex.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Successfully geting Advertise"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@GetMapping(value = "user/advertise/{match}" , consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<AdvertiseDto> getAdvertiseSearchByText(@PathVariable String match) {
		return new ResponseEntity<AdvertiseDto>(olxAdvertiseServie.getAdvertiseSearchByText(match),HttpStatus.OK);
	}
	
	@Operation(summary = "Get Advertise by ID", description = "Get Advertise by ID.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Successfully geting Advertise"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	@GetMapping(value = "user/advertise/{advertiseId}", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<AdvertiseDto> getAdvertiseSearchByadId(@PathVariable String advertiseId,@RequestHeader("Authorization") String authHeader,@RequestHeader("EXPECTED_ROLES") String expectedRoles) {
		return new ResponseEntity<AdvertiseDto>(olxAdvertiseServie.getAdvertiseSearchByadId(advertiseId),HttpStatus.OK);
	}
	
	@Operation(summary = "Get Advertise by Search", description = "Get Advertise by Search.")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "Successfully geting Advertise"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })	
	@GetMapping(value="/user/advertise/search", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<AdvertiseDto> searchStocksByFilterCriteria(@RequestParam(name="searchText", required = false)String searchText,
			@RequestParam(name = "title", required = false)String name, @RequestParam(name="market", required = false)String market,
			@RequestParam(name="sortedBy", required = false)String sortedBy,
			@RequestParam(name = "startIndex", defaultValue="0", required = false)int startIndex,
			@RequestParam(name="records", defaultValue = "10", required = false)int records
			) {
		return olxAdvertiseServie.searchAdvertiseByFilterCriteria(searchText, name, market, sortedBy, startIndex, records);
	}
	
	@DeleteMapping(value = "user/advertise/{advertiseId}", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<AdvertiseDto> getAdvertiseDeleteByadId(@PathVariable String advertiseId,@RequestHeader("Authorization") String authHeader,@RequestHeader("EXPECTED_ROLES") String expectedRoles) {
		return new ResponseEntity<AdvertiseDto>(olxAdvertiseServie.getAdvertiseSearchByadId(advertiseId),HttpStatus.OK);
	}
}
