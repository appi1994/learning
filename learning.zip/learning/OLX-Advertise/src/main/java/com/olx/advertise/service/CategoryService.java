package com.olx.advertise.service;


import com.olx.advertise.dto.Category;

public interface CategoryService {
	
	
	public Category getCategoryByID(int id); 
	

}
