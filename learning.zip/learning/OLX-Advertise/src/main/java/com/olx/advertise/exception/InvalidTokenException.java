package com.olx.advertise.exception;

public class InvalidTokenException extends RuntimeException {
	
	private String message;

	@Override
	public String toString() {
		return "InvalidTokenException [message=" + message + "]";
	}

	public InvalidTokenException() {
	}

	public InvalidTokenException(String message) {
		this.message = message;
	}
}