package com.olx.advertise.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.olx.advertise.dto.AdvertiseDto;
import com.olx.advertise.dto.NewAdvertisementPostRequest;
import com.olx.advertise.dto.NewAdvertisementPostResponse;

public interface OlxAdvertiseServie {
	
	public NewAdvertisementPostResponse postNewAdvertise(NewAdvertisementPostRequest advertiseDto,String authHeader,String expectedRoles);
	
	public AdvertiseDto getAdvertisebyID( AdvertiseDto advertiseDto, String id,String authHeader,String expectedRoles);
	
	public List<AdvertiseDto> getAdvertiseList(String authHeader,String expectedRoles);
	
	public AdvertiseDto getAdvertiseByID(@PathVariable String id,String authHeader,String expectedRoles);
	
	public AdvertiseDto getAdvertiseSearchByText( String match);
	
	public AdvertiseDto getAdvertiseSearchByadId( String advertiseId);
	
	public AdvertiseDto getAdvertiseSearch(LocalDate onDate);
	
	public List<AdvertiseDto> searchAdvertiseByFilterCriteria(String searchText, String name, String market, String sortedBy,
			int startIndex, int records) ;
	
	public AdvertiseDto getAdvertiseDeleteByadId( String advertiseId,String authHeader,String expectedRoles);
	
}