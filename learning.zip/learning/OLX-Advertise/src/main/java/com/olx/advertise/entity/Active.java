package com.olx.advertise.entity;

public enum Active {

	TRUE, FALSE
	
}

