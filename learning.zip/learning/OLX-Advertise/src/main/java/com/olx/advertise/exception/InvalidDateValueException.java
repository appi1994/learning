package com.olx.advertise.exception;

public class InvalidDateValueException extends RuntimeException {
	
	private String message;

	@Override
	public String toString() {
		return "InvalidDateValueException [message=" + message + "]";
	}

	public InvalidDateValueException() {
	}

	public InvalidDateValueException(String message) {
		this.message = message;
	}
	
}
