package com.olx.advertise.exception;


import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
 
	@ExceptionHandler(value = InvalidAdvertiseIdException.class)
	public ResponseEntity<Object> handleInvalidStockException(RuntimeException exception, WebRequest request) {
		String errorMessage = "{\"error\":" + exception.toString() + " }";
		ResponseEntity<Object> response = handleExceptionInternal(exception, errorMessage, new HttpHeaders(),
				HttpStatus.BAD_REQUEST, request);
		return response;
	}
	
	@ExceptionHandler(value = DateNotFoundException.class)
	public ResponseEntity<Object> handleDateNotFoundException(RuntimeException exception, WebRequest request) {
		String errorMessage = "{\"error\":" + exception.toString() + " }";
		ResponseEntity<Object> response = handleExceptionInternal(exception, errorMessage, new HttpHeaders(),
				HttpStatus.BAD_REQUEST, request);
		return response;
	}
	
	@ExceptionHandler(value = InvalidDateValueException.class)
	public ResponseEntity<Object> handleInvalidDateValueException(RuntimeException exception, WebRequest request) {
		String errorMessage = "{\"error\":" + exception.toString() + " }";
		ResponseEntity<Object> response = handleExceptionInternal(exception, errorMessage, new HttpHeaders(),
				HttpStatus.BAD_REQUEST, request);
		return response;
	}
	
}
