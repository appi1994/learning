package com.olx.advertise.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.olx.advertise.dto.Category;
@Service
public class CategoryServiceImpl implements CategoryService {

	
	@Autowired
	RestTemplate restTemplate;

	@Override
	public Category getCategoryByID(int id) {
		Category category[];
		List<Category> categories= new ArrayList<>();
		String url = "http://localhost:9001/advertise/category/" ;
//		restTemplate.exchange(url, HttpMethod.GET, category, List);
//		category = restTemplate.getForObject(url, Category.class);
//		restTemplate.setInterceptors(Collections.singletonList(new HttpHeaders("Accept",
//                MediaType.APPLICATION_JSON.toString())));
//		restTemplate.new RestTemplateBuilder()
//        .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
//        .build();
		HttpHeaders headers = new HttpHeaders();

		// set `Content-Type` and `Accept` headers
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<Object> requestEntity = new HttpEntity<Object>("ss",headers);
		ResponseEntity<List> response =
				  restTemplate.exchange(
				  "http://localhost:8080/olx/advertise/category",HttpMethod.GET,requestEntity,
				  List.class);
		categories = response.getBody();
		System.out.println(categories.toString());
		return categories.get(0);
	}

}
