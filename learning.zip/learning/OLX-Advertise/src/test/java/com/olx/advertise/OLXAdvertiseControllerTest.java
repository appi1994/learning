package com.olx.advertise;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.olx.advertise.controller.OLXAdvertiseController;
import com.olx.advertise.dto.NewAdvertisementPostRequest;
import com.olx.advertise.dto.NewAdvertisementPostResponse;
import com.olx.advertise.service.OlxAdvertiseServie;
import com.olx.masterdata.dto.CategoryDto;


@WebMvcTest(OLXAdvertiseController.class)
public class OLXAdvertiseControllerTest {

	@Autowired
	MockMvc mockMvc;//used to send request
	
	@MockBean
	OlxAdvertiseServie olxMasterdataService;
	
	@Autowired
	ObjectMapper objectMapper;
	
	@Test
    void testPostNewAdvertise() throws Exception {
        // Arrange
        NewAdvertisementPostRequest request = new NewAdvertisementPostRequest(/* ... */);
        String authHeader = "Bearer your-auth-token";
        String expectedRoles = "ROLE_USER";

        // Mock the service method
        NewAdvertisementPostResponse mockResponse = new NewAdvertisementPostResponse(/* ... */);
        when(olxMasterdataService.postNewAdvertise(request, authHeader, expectedRoles))
            .thenReturn(mockResponse);

        // Act
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
                .post("/olx/advertise")
//                .content(asJsonString(request))
                .header("Authorization", authHeader)
                .header("EXPECTED_ROLES", expectedRoles)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andReturn();

        // Assert
        String resString = mvcResult.getResponse().getContentAsString();
		assertTrue(resString.contains("Success"));
    }
	

}
