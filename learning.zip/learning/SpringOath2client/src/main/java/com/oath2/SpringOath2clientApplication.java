package com.oath2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOath2clientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringOath2clientApplication.class, args);
	}

}
