package com.oath2.controller;

import java.security.Principal;

import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

	@GetMapping(value = "/")
	public String getName(Principal principal) {
		OAuth2AuthenticationToken oath= (OAuth2AuthenticationToken) principal;
	String username = oath.getPrincipal().getAttribute("login");
		return "hello  " + username	; 
	}
}
