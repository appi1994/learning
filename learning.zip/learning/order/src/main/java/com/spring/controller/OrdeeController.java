package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
public class OrdeeController {
	@Autowired
	RestTemplate restTemplate;
	
	@CircuitBreaker(name = "ITEMSERVICE",fallbackMethod = "fallbackGetOrder")
	@GetMapping(value="/order")
	public String getOrder() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity entity = new HttpEntity(headers);
		ResponseEntity<String> result =
			restTemplate.exchange("http://localhost:7000/item",
					HttpMethod.GET, entity, String.class);
		return "Order details: " + result.getBody();
	}
	//same parameter same return type // pass throwbale if request throwing error 
	public String fallbackGetOrder(Throwable ex) {
		return "fallbackGetOrder";
	}
}
