package com.junit;

import java.util.Objects;

public class StringOperations {

	public String concat;
	
	public String concat(String a,String b) {
		concat = a+b;
		return concat;
	}
	
	public String getCharacter(int index) {
		return String.valueOf(concat.toCharArray()[index]);
	}
//	
	public int getLength() {
		return concat.length();
	}

	@Override
	public String toString() {
		return "StringOperations [concat=" + concat + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(concat);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StringOperations other = (StringOperations) obj;
		return Objects.equals(concat, other.concat);
	}
	
	
}
