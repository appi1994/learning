package com.junit;

import java.util.Random;

public class Arthmectic {
		public int add(int x, int y) {
			return x + y;
		}
		public int divide(int x, int y) {
			return x / y;
		}
		public boolean randomDigit(int x) {
//			Random r = new Random();
//			int randomInt = r.nextInt(100) + 1;
			if((x>0)&&(x<100) )		
				return true;
			return false;
		}
		
//		public String concat(String a,String b) {
//			return a+b;
//		}
//		
//		public String getCharacter(int index) {
//			return ;
//		}
	}
