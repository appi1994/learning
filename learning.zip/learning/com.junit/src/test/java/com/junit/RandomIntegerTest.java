package com.junit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class RandomIntegerTest {
	
	int x;

	public RandomIntegerTest(int x) {
		this.x = x;
	}

	@Parameters
	public static Collection testData() {
		Collection col = Arrays.asList(new Object[] {  3 ,  22 , 9 , 20  });
		return col;
	}

	
	public static Arthmectic arthmectic;
	@BeforeClass
	public static void beforeClass() {
		arthmectic = new Arthmectic();
	System.out.println("inside before class");	
	}
	
	@AfterClass
	public static void afterClass() {
		arthmectic = null;
	System.out.println("inside after class");	
	}
	
	@Before
	public void beforeMeth() {
		System.out.println("inside before method");
	}
	
	@After
	public void aftereMeth() {
		System.out.println("inside after method");
	}
	
	@Test
	public  void testRandomDigit () {
		assertTrue(arthmectic.randomDigit(x));
	}

}
