package com.junit;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class TestArthmetic {
	
	Arthmectic a = new Arthmectic();
	
	
	@Test
	public void testAdd1 () {
		assertEquals(a.add(5, 5), 10);
	}

	@Test
	public void testAdd2 () {
		assertEquals(a.add(30, 5), 35);
	}
	
	@Test
	public void testdivide () {
		assertEquals(a.divide(5, 5), 1);
	}
	
	@Test(expected = ArithmeticException.class)
	public void testdivide2 () {
		assertEquals(a.divide(2, 0), 5);
	}
	
	@BeforeClass
	public static void beforeClass() {
	System.out.println("inside before class");	
	}
	
	@AfterClass
	public static void afterClass() {
	System.out.println("inside after class");	
	}
	
	@Before
	public void beforeMeth() {
		System.out.println("inside before method");
	}
	
	@After
	public void aftereMeth() {
		System.out.println("inside after method");
	}
	
	@Test
	@Ignore
	public void testdivide3 () {
		assertEquals(a.divide(20, 2), 10);
	}
}
