package com.junit;

public class UserAuthoTesting {

}
