package com.junit;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class StringOperationsTest {

	String x, y;
	
	public StringOperations s = new StringOperations();

	public StringOperationsTest(String x, String y) {
		this.x = x;
		this.y = y;
	}

	@Parameters
	public static Collection testData() {
		Collection col = Arrays.asList(new Object[][] { { "Assda", "Asdasdad" }, { "adsasd", "anile" }, { "asdadsds", "asdasdad" }, { "As", "atj" }, { "ss", "dd" } });
		return col;
	}
	
	
	@Test
	public void testCase1() {
		assertEquals(s.concat(x, y), x + y);
	}
	
	@Test
	public void testCase2() {
		s.concat(y, x);
		assertEquals(s.getLength(), (x + y).length());
	}

}
